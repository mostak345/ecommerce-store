import React from 'react';

const products = [
  { id: 1, name: 'Stylish Sneakers', price: '$59.99', image: 'https://via.placeholder.com/200x150.png?text=Sneakers' },
  { id: 2, name: 'Casual T-Shirt', price: '$19.99', image: 'https://via.placeholder.com/200x150.png?text=T-Shirt' },
  { id: 3, name: 'Modern Backpack', price: '$34.99', image: 'https://via.placeholder.com/200x150.png?text=Backpack' },
];

export default function Home() {
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 text-center">My E-Commerce Store</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {products.map((product) => (
          <div key={product.id} className="border rounded-lg shadow hover:shadow-lg p-4">
            <img src={product.image} alt={product.name} className="w-full h-40 object-cover mb-4 rounded" />
            <h2 className="text-xl font-semibold mb-2">{product.name}</h2>
            <p className="text-gray-700 mb-4">{product.price}</p>
            <button className="bg-blue-600 text-white px-4 py-2 rounded">Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
  );
}